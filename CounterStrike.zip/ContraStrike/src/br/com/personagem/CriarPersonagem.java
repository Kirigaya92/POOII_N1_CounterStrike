package br.com.personagem;

public interface CriarPersonagem {

	Persongem criarPersonagem(String tipoPersonagem); 
	
	
}
