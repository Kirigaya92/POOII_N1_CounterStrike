package br.com.personagem;




import br.com.personagens.contraterrorista.CSG9;
import br.com.personagens.contraterrorista.SealTeam;


public class EscolherPersonagem implements CriarPersonagem{

		
	Persongem pj;
	
	//parte do padrao de projeto factory Methody
	//metodo que escolhe qual persornagem deve ser instanciado	
	public Persongem criarPersonagem(String tipoPersonagem) { //metodo que recebe uma String dizendo que personagem deve se criado;
		
		pj = null; 
				
		switch(tipoPersonagem.toUpperCase()){ //transforma a string personagem em maiuscula;
		
		case "CSG9":
			
			pj = new CSG9(); // pj recebe uma instancia da class CSG9;
			
			break;
			
		case "SEALTEAM":
			
			pj = new SealTeam(); // pj recebe uma instancia da class Seal Team;
			
			break;
		}
				
		return pj; //retorna a variavel pj contendo o objeto instaciado;
	}
	
}
