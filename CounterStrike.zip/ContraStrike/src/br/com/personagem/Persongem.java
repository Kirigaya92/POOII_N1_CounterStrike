package br.com.personagem;


import br.com.armas.Armas;

// classe modelo personagem;

public abstract class Persongem {

	private String tipo; // tipo do personagem;
		
	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	// parte do padrao de projeto strategy;
	public void equipar(Armas a){ //recebe uma interface Arma;
		a.atirar(); //metodo da classe concreta que implementa a interface Arma;
	}
	
	@Override
	public String toString() { //sobreescreve o metodo toString para impressao direta do objeto;
		// TODO Auto-generated method stub
		return "Tipo: "+getTipo(); // retorna o tipo do personagem;
	}

}
