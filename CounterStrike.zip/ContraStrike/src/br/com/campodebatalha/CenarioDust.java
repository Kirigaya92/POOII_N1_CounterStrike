package br.com.campodebatalha;

import br.com.armas.contraterroristas.Clarion;
import br.com.personagem.CriarPersonagem;
import br.com.personagem.EscolherPersonagem;
import br.com.personagem.Persongem;




public class CenarioDust {

	public static void main(String[] args) {

		CriarPersonagem c = new EscolherPersonagem();
		
		Persongem pj = c.criarPersonagem("csg9");
		
		System.out.println(pj.getTipo());
		pj.equipar(new Clarion());
		
	}

}
