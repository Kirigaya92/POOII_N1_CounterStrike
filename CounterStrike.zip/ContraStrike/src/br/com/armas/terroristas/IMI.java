package br.com.armas.terroristas;

import br.com.armas.Armas;

public class IMI implements Armas {

	@Override
	public void atirar() {

		System.out.println("Atirando com IMI Galil (IDF Defender)");
		
	}

}
