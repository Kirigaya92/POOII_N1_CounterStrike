package br.com.armas.terroristas;

import br.com.armas.Armas;

public class Glock implements Armas{

	@Override
	public void atirar() {
		
		System.out.println("Atirando com Glock G18 Select Fire");
		
	}

}
