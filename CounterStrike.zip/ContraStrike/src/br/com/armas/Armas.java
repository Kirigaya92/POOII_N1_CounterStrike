package br.com.armas;

public interface Armas {

	void atirar();
	
}
