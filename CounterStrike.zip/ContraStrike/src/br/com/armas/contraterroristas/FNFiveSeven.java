package br.com.armas.contraterroristas;

import br.com.armas.Armas;

public class FNFiveSeven implements Armas{

	@Override
	public void atirar() {
		
		System.out.println("Atirando arma FN Five Seven");
		
	}

}
