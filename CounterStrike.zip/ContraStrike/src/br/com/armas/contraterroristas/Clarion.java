package br.com.armas.contraterroristas;

import br.com.armas.Armas;

public class Clarion implements Armas{

	@Override
	public void atirar() {
		
		System.out.println("Atirando com FAMAS (Clarion 5.56)");
		
	}

}
