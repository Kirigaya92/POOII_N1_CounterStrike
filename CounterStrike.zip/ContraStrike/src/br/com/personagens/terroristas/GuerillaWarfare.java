package br.com.personagens.terroristas;


import br.com.personagem.Persongem;

public class GuerillaWarfare extends Persongem {

	
	public GuerillaWarfare() {
		setTipo("Guerilla Warfare");
		
	}
	
}