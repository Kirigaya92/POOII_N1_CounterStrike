package br.com.personagens.terroristas;


import br.com.personagem.Persongem;

public class FenixConexion extends Persongem {
	
	
	
	public FenixConexion() {
		setTipo("FenixConexion");
			
	}

	
	
}