package br.com.personagens.contraterrorista;


import br.com.personagem.Persongem;

public class CSG9 extends Persongem {
	
	public CSG9() {
		setTipo("CSG - 9");
		
	}
}
