package br.com.personagens.contraterrorista;




import br.com.personagem.Persongem;

public class SealTeam extends Persongem {


	public SealTeam() {
		setTipo("Seal Team");
		
			
	}

	
}
